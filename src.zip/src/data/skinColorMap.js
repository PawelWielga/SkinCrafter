const skinColorMap = {
  Human: ["Light", "Medium", "Dark"],
  Elf: ["Pale", "Fair"],
  Dwarf: ["Tan", "Olive"],
  Orc: ["Green", "Dark Green"],
  Zombie: ["Rotten", "Mossy"],
  Skeleton: ["Bone"],
  Enderman: ["Void"],
};

export default skinColorMap;
