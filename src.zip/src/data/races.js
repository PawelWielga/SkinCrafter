const races = [
  "Human",
  "Elf",
  "Dwarf",
  "Orc",
  "Zombie",
  "Skeleton",
  "Enderman",
];

export default races;
