import "./wardrobe.css";

function WardrobeEyescolor() {
  return <div>{WardrobeEyescolor.name}</div>;
}

export default WardrobeEyescolor;
