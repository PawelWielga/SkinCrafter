import "./wardrobe.css";

function WardrobeEyes() {
  return <div>{WardrobeEyes.name}</div>;
}

export default WardrobeEyes;
